# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(webrtcDtls src/webrtcDtls.cpp)
set_property(TARGET webrtcDtls PROPERTY CXX_STANDARD 11)
target_link_libraries(webrtcDtls lionss pthread)

add_executable(flaxen src/flaxen.cpp)
set_property(TARGET flaxen PROPERTY CXX_STANDARD 11)
target_link_libraries(flaxen lionss pthread)

add_executable(zfs_scrub src/zfs_scrub.cpp)
set_property(TARGET zfs_scrub PROPERTY CXX_STANDARD 11)
target_link_libraries(zfs_scrub lionss pthread)

add_executable(canbus_filter src/canbus_filter.cpp)
set_property(TARGET canbus_filter PROPERTY CXX_STANDARD 11)
target_link_libraries(canbus_filter lionss pthread)

add_executable(helmLint src/helmLint.cpp)
set_property(TARGET helmLint PROPERTY CXX_STANDARD 11)
target_link_libraries(helmLint lionss pthread)

add_executable(loraMerge src/loraMerge.cpp)
set_property(TARGET loraMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(loraMerge lionss pthread)

add_executable(ashford src/ashford.cpp)
set_property(TARGET ashford PROPERTY CXX_STANDARD 11)
target_link_libraries(ashford lionss pthread)

add_executable(alpnSelect src/alpnSelect.cpp)
set_property(TARGET alpnSelect PROPERTY CXX_STANDARD 11)
target_link_libraries(alpnSelect lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(cnv-segment src/cnv-segment.cpp)
set_property(TARGET cnv-segment PROPERTY CXX_STANDARD 11)
target_link_libraries(cnv-segment lionss pthread)

add_executable(FastqcTrim src/FastqcTrim.cpp)
set_property(TARGET FastqcTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(FastqcTrim lionss pthread)

add_executable(TmuxPane src/TmuxPane.cpp)
set_property(TARGET TmuxPane PROPERTY CXX_STANDARD 11)
target_link_libraries(TmuxPane lionss pthread)

add_executable(crystal-null src/crystal-null.cpp)
set_property(TARGET crystal-null PROPERTY CXX_STANDARD 11)
target_link_libraries(crystal-null lionss pthread)

add_executable(glossary-check src/glossary-check.cpp)
set_property(TARGET glossary-check PROPERTY CXX_STANDARD 11)
target_link_libraries(glossary-check lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(nightjar src/nightjar.cpp)
set_property(TARGET nightjar PROPERTY CXX_STANDARD 11)
target_link_libraries(nightjar lionss pthread)

add_executable(pg_reindex src/pg_reindex.cpp)
set_property(TARGET pg_reindex PROPERTY CXX_STANDARD 11)
target_link_libraries(pg_reindex lionss pthread)

add_executable(branchHint src/branchHint.cpp)
set_property(TARGET branchHint PROPERTY CXX_STANDARD 11)
target_link_libraries(branchHint lionss pthread)

add_executable(onnxShapeinfer src/onnxShapeinfer.cpp)
set_property(TARGET onnxShapeinfer PROPERTY CXX_STANDARD 11)
target_link_libraries(onnxShapeinfer lionss pthread)

add_executable(IoUringSqpoll src/IoUringSqpoll.cpp)
set_property(TARGET IoUringSqpoll PROPERTY CXX_STANDARD 11)
target_link_libraries(IoUringSqpoll lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(Halcyon src/Halcyon.cpp)
set_property(TARGET Halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(Halcyon lionss pthread)

add_executable(coldspring src/coldspring.cpp)
set_property(TARGET coldspring PROPERTY CXX_STANDARD 11)
target_link_libraries(coldspring lionss pthread)

add_executable(GliderFleet src/GliderFleet.cpp)
set_property(TARGET GliderFleet PROPERTY CXX_STANDARD 11)
target_link_libraries(GliderFleet lionss pthread)

add_executable(cgroupFreeze src/cgroupFreeze.cpp)
set_property(TARGET cgroupFreeze PROPERTY CXX_STANDARD 11)
target_link_libraries(cgroupFreeze lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(latticeQcd src/latticeQcd.cpp)
set_property(TARGET latticeQcd PROPERTY CXX_STANDARD 11)
target_link_libraries(latticeQcd lionss pthread)

add_executable(fft_bluestein src/fft_bluestein.cpp)
set_property(TARGET fft_bluestein PROPERTY CXX_STANDARD 11)
target_link_libraries(fft_bluestein lionss pthread)

