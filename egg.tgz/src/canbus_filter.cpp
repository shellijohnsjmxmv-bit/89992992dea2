// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Filter CAN frames\n", stdout);
  return lionss_run_workload("canbus_filter");
}
