// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Dispatch glider fleet"); }
int main(){
  announce();
  return lionss_run_workload("GliderFleet");
}
