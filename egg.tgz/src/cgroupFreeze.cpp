// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Freeze cgroup tasks\n", stdout);
  return lionss_run_workload("cgroupFreeze");
}
