// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Check nil safety\n", stdout);
  return lionss_run_workload("crystal-null");
}
