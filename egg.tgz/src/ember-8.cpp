// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate ember drift"); }
int main(){
  announce();
  return lionss_run_workload("ember-8");
}
