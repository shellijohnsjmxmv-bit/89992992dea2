// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Route ashford crossing\n", stdout);
  return lionss_run_workload("ashford");
}
